py main.py
pause